 
/** @type {import('next').NextConfig} */
const nextConfig = {
 
  basePath: '',
    experimental: {
      // appDir: true,
     
    },
  };
  
  export default nextConfig;
  
 