export const metadata = {
  title: "Join AEJSINFO: Start Your Career in Security Excellence",
  description:
    "AEJSINFO has 15 years of experience in delivering comprehensive security services and security solutions. Expert protection for all your needs.",
  keywords: "Security Services, Security Solutions",
};
export default function RootLayout({ children }) {
  return <>{children}</>;
}
