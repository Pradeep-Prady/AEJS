export const metadata = {
  title: "AEJSINFO: 15 Years of Expertise in Security Services & Protection",
  description:
    "AEJSINFO has 15 years of experience in delivering comprehensive security services and security solutions. Expert protection for all your needs.",
  keywords: "Security Services, Security Solutions",
};
export default function RootLayout({ children }) {
  return <>{children}</>;
}
