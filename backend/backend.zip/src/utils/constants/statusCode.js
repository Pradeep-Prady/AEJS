export const BADREQUEST = 400;
export const SUCCESS = 200;
export const NOTFOUND = 404;
export const SERVERERROR = 500;
export const UNAUTHORIZED = 401;
